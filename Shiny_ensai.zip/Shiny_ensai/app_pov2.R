# load required packages (install if not already installed)
if(!require(readxl)) install.packages("readxl")
if(!require(ggplot2)) install.packages("ggplot2")
if(!require(d3wordcloud)) install.packages("d3wordcloud")
if(!require(dplyr)) install.packages("dplyr")
if(!require(colourpicker)) install.packages("colourpicker")
if(!require(wordcloud2)) install.packages("wordcloud2")
if(!require(corpus)) install.packages("corpus")
if(!require(tm)) install.packages("tm")
if(!require(leaflet)) install.packages("leaflet")
if(!require(plotly)) install.packages("plotly")





###load necessary packages 
library(shiny)
library(readxl)
library(ggplot2)
library("d3wordcloud")
library(colourpicker)  #package to select color
library(wordcloud2)  # Natural language processing package
library(corpus) # Natural language processing package
library(tm) # Natural language processing package
library(dplyr)  

 

# A small css file for formatting
my_css <- "
#download_data {
  /* Change the background color of the download button
     to orange. */
  background: orange;

  /* Change the text size to 20 pixels. */
  font-size: 20px;
}

#table {
  /* Change the text color of the table to red. */
  color: red;
}
"


# A function to select countries with highest inequality 
get_top_pov<-function(){
  poverty_topic %>% 
    filter(year == input$year) %>% 
    filter(region == input$regionname) %>% 
    slice_max(gini_index, n = 10)
}


# Natural language processing function that aims at identifying the most 
# important word from a text and display it in a way that the most 
# important words appear up-front and bigger while the less important
# word from the text appears smaller and behind.
create_wordcloud <-function(data, num_words = 100, background = "white") {
  
  # If text is provided, convert it to a dataframe of word frequencies
  if (is.character(data)) {
    corpus <- Corpus(VectorSource(data))
    corpus <- tm_map(corpus, tolower)
    corpus <- tm_map(corpus, removePunctuation)
    corpus <- tm_map(corpus, removeNumbers)
    corpus <- tm_map(corpus, removeWords, stopwords("english"))
    tdm <- as.matrix(TermDocumentMatrix(corpus))
    data <- sort(rowSums(tdm), decreasing = TRUE)
    data <- data.frame(word = names(data), freq = as.numeric(data))
  }
  
  # Make sure a proper num_words is provided
  if (!is.numeric(num_words) || num_words < 3) {
    num_words <- 3
  }  
  
  # Grab the top n most common words
  data <- head(data, n = num_words)
  if (nrow(data) == 0) {
    return(NULL)
  }
  
  wordcloud2(data, backgroundColor = background)
}


# Setting work directory and import files. 
setwd("/Users/deudibegildas/datacamp/datacamp/Shiny_ensai")

poverty_topic <- read_excel("poverty_topic.xlsx")
poverty_topic4 <- read_excel("poverty_topic4.xls")


# Define UI 
ui <- fluidPage(
  tags$style(my_css),
  # Application title
  titlePanel("Sustainable indicators across the world"),
  # Defining the theme of the page
  theme = shinythemes::shinytheme("cerulean"),
  # Sidebar with a slider input for number of bins 
  sidebarLayout(
    sidebarPanel(
      sliderInput(inputId = "year", label = "Year",
                  min = 1960, max = 2020,
                  value = c(2000, 2010)),
      
      # Add a continent dropdown selector
      selectInput("regionname", "Region",
                  choices = c("All", unique(poverty_topic$regionname)),
                  #multiple = TRUE,
                  selected = "Sub-Saharan Africa"), 
      numericInput("size", "Point size", 1, 1),
      checkboxInput("fit", "Add line of best fit", FALSE),
      radioButtons("color", "Point color",
                   choices = c("blue", "red", "green", "black")),
      # Add a download button
      downloadButton(outputId = "download_data", label = "Download"), 
      radioButtons(
        inputId = "source",
        label = "Word source",
        choices = c(
          "Use your own words" = "own",
          "Upload a file" = "file"
        )
      ),
      conditionalPanel(
        condition = "input.source == 'own'",
        textAreaInput("text", "Enter text", rows = 7)
      ),
      conditionalPanel(
        condition = "input.source == 'file'",
        fileInput("file", "Select a file")
      ),
      numericInput("num", "Maximum number of words",
                   value = 100, min = 5),
      colourInput("col", "Background color", value = "white"),
      # Add a "draw" button to the app
      actionButton(inputId = 'draw', label = 'Draw!')
      ),
    
    # Show a plot of the generated distribution
    mainPanel(
      tabsetPanel(
        tabPanel('tabset1',
        plotly::plotlyOutput("plot", width=800, height=450),
        plotly::plotlyOutput("plot2", width=800, height=400)),
      tabPanel('tabset2', 
        DT::DTOutput("table")),
      tabPanel('Word Cloud', wordcloud2Output("cloud")), 
      tabPanel('map', leafletOutput("map", width = 1000, height = 600))
      )
    )
  )
)

# Define server logic required to draw a histogram
server <- function(input, output) {
  output$download_data <- downloadHandler(
    # The downloaded file 
    filename = "poverty_topic.csv",
    content = function(file) {
      # The code for filtering the data is copied from the
      # renderTable() function
      data <- subset(poverty_topic,
                     year >= input$year[1] 
                     & year <= input$year[2])
      
      if (input$regionname != "All") {
        data <- subset(
          data,
          regionname == input$regionname
        )
      }
      get_top_pov(data)
      
      # Write the filtered data into a CSV file
      write.csv(data, file, row.names = FALSE)
    }
  )
  
  output$plot <- plotly::renderPlotly({
    # Subset the dataset by the chosen continents
    data <- subset(poverty_topic,
                    year >= input$year[1] 
                   & year <= input$year[2])
    
    if (input$regionname != "All") {
      data <- subset(
        data,
        regionname == input$regionname
      )
    }
    data
    
    p <- ggplot(data, aes(gini_index, pov_headcountpovnat)) +
      geom_point(size = input$size, col = input$color) +
      scale_x_log10() 
    
    if (input$fit) {
      p <- p + geom_smooth(method = "lm")
    }
    p
})
  
  output$plot2 <- plotly::renderPlotly({
    # Subset the dataset by the chosen continents
    data <- subset(poverty_topic,
                   year >= input$year[1] 
                   & year <= input$year[2])
    
    if (input$regionname != "All") {
      data <- subset(
        data,
        regionname == input$regionname
      )
    }
    data
    
    p2 <- ggplot(data ) + 
      stat_summary(
        mapping = aes(x = countryname, y = pov_headcountpovnat),
        fun.min = min,
        fun.max = max,
        fun = median
      ) +  theme(axis.text.x = element_text(angle = 90))
    p2
  })
  
  output$table <-  DT::renderDT({
    data <- subset(poverty_topic,
                   year >= input$year[1] 
                   & year <= input$year[2])
    
    data2<- data  %>% 
    group_by(countryname) %>% 
      summarise(across(everything(), .f = list(mean = mean, max = max, sd = sd), na.rm = TRUE))

    DT::datatable(data2)
    if (input$regionname != "All") {
      data <- subset(
        data,
        regionname == input$regionname
      )
    }
    DT::datatable(data2)
  })
  
  data_source <- reactive({
    if (input$source == "own") {
      data <- input$text
    } else if (input$source == "file") {
      data <- input_file()
    }
    return(data)
  })
  
  input_file <- reactive({
    if (is.null(input$file)) {
      return("")
    }
    readLines(input$file$datapath)
  })
  
  output$cloud <- renderWordcloud2({
    # Add the draw button as a dependency to
    # cause the word cloud to re-render on click
    input$draw
    isolate({
      create_wordcloud(data_source(), num_words = input$num,
                       background = input$col)
    })
  })
  
  output$map <- renderLeaflet({
    data_map <-  subset(poverty_topic4,
             year >= input$year[1] 
             & year <= input$year[2])
      
      if (input$regionname != "All") {
        data_map <- subset(
          data_map,
          regionname == input$regionname
        )
      }

    data_map %>% 
    leaflet() %>%
      addTiles() %>% 
      addCircleMarkers(
        popup = ~ incomelevelname, radius = ~ sqrt(elec_access)*2,
        fillColor = 'lightgreen', color = 'red', weight = 1
      )
      #addProviderTiles("CartoDB") %>%
      # Use dc_hq to add the hq column as popups
      #addMarkers(lng = c(-73.985750 ,  4.717863), lat = c(40.74856 ,50.88136),
                 #popup = c("DataCamp - NYC" ,    "DataCamp - Belgium"))

  })
 

}
# Run the application 
shinyApp(ui = ui, server = server)